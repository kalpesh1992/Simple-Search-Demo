//
//  FavoriteCompanyListViewController.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class FavoriteCompanyListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    // MARK: Outlet
    
    @IBOutlet var btnMenu: UIButton!
    @IBOutlet var tblFavoriteCompanyList: UITableView!
    
    var arrLikeCompanyList = NSMutableArray()
    var dictLikeCompanyDetail = NSMutableDictionary()
    let userDefaults = UserDefaults.standard

    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        leftMenu()
        
        
        if userDefaults.object(forKey: "Favorite") != nil{
            
            let arrMutableCopy:NSArray = userDefaults.object(forKey: "Favorite") as! NSArray
            arrLikeCompanyList = arrMutableCopy.mutableCopy() as! NSMutableArray
        }
    }
    
    // MARK: Set Status Bar Color
    
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    
    
    // MARK: Create Left Menu
    
    func leftMenu() {
        if self.revealViewController() != nil {
            
            revealViewController().rearViewRevealWidth = 240
            btnMenu.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: UIControlEvents.touchUpInside)
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
    
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int
    {
        return arrLikeCompanyList .count
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! FavoriteCompanyListTableViewCell
        
        dictLikeCompanyDetail = (arrLikeCompanyList .object(at: indexPath.row) as? NSMutableDictionary)!
        
        cell.lblCompanyName.text = dictLikeCompanyDetail .object(forKey: "name") as? String
        cell.lblCompnayYear.text = dictLikeCompanyDetail .object(forKey: "year") as? String

        cell.btnUnLike.tag = indexPath.row
        cell.btnShare.tag = indexPath.row
        cell.btnUnLike .addTarget(self, action: #selector(btnCompanyUnLike(sender:)), for: UIControlEvents.touchUpInside)
        cell.btnShare .addTarget(self, action: #selector(btnCompanyShare(sender:)), for: UIControlEvents.touchUpInside)
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        dictLikeCompanyDetail = (arrLikeCompanyList .object(at: indexPath.row) as? NSMutableDictionary)!

        self.performSegue(withIdentifier: "Detail", sender: self)

    }
    
    
    // MARK: UnLike Company
    
    func btnCompanyUnLike(sender : UIButton!) {
        
        dictLikeCompanyDetail = (arrLikeCompanyList .object(at: sender.tag) as? NSMutableDictionary)!
        
        arrLikeCompanyList .remove(dictLikeCompanyDetail)
        tblFavoriteCompanyList .reloadData()
        
        userDefaults.set(arrLikeCompanyList, forKey: "Favorite")
        userDefaults.synchronize()
        
    }
    
    
    // MARK: Share Company
    
    func btnCompanyShare(sender : UIButton!) {
        dictLikeCompanyDetail = (arrLikeCompanyList .object(at: sender.tag) as? NSMutableDictionary)!
        
        let myWebsite = NSURL(string:dictLikeCompanyDetail .object(forKey: "Url") as! String)
        
        guard let url = myWebsite else {
            print("nothing found")
            return
        }
        
        
        // set up activity view controller
        let textToShare = [ url ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        if #available(iOS 8.0, *) {
            activityViewController.popoverPresentationController?.sourceView = self.view
        } else {
            // Fallback on earlier versions
        } // so that iPads won't crash
        
        // exclude some activity types from the list (optional)
        activityViewController.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook ]
        
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "Detail" {
            
            let vcCompanyCaseDetail = segue.destination as? CompanyDetailViewController
            vcCompanyCaseDetail?.dictCompanyDetail = dictLikeCompanyDetail
            
        }
    }
    

}
