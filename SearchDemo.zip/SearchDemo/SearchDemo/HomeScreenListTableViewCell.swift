//
//  HomeScreenListTableViewCell.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class HomeScreenListTableViewCell: UITableViewCell {
    
    
    // MARK: Outlet
    
    @IBOutlet var lblCompanyName: UILabel!
    @IBOutlet var lblCompanyYear: UILabel!
    @IBOutlet var btnLike: UIButton!
    @IBOutlet var btnUnLike: UIButton!
    @IBOutlet var btnShare: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
