//
//  HomeScreenViewController.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class HomeScreenViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    // MARK: Outlet
    
    @IBOutlet var btnMenu: UIButton!
    @IBOutlet var btnCountryList: UIButton!
    @IBOutlet var btnIndustryList: UIButton!
    @IBOutlet var btnCategoryList: UIButton!
    @IBOutlet var tblCompanyList: UITableView!
    
    
    
    var items = NSArray()
    var itemsInTable = NSMutableArray()
    var arrLikeCompanyList:NSMutableArray = []
    
    var dict = NSDictionary()
    var dictCompanyDetail = NSMutableDictionary()
    var arrFilterList = NSArray()
    let userDefaults = UserDefaults.standard



    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        leftMenu()
        setScreenLayOut()
     



        if userDefaults.object(forKey: "Favorite") != nil{
            
            let arrMutableCopy:NSArray = userDefaults.object(forKey: "Favorite") as! NSArray
            arrLikeCompanyList = arrMutableCopy.mutableCopy() as! NSMutableArray
        }
       
        
        if let path = Bundle.main.path(forResource: "HomeScreenList", ofType: "plist") {
            dict = NSDictionary(contentsOfFile: path)!
        }
        
        itemsInTable=dict .value(forKey: "Items") as! NSArray as! NSMutableArray
        
    }
    
    // MARK: Set Status Bar Color
    
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    
    // MARK: Create Left Menu

    func leftMenu() {
        if self.revealViewController() != nil {
            
            revealViewController().rearViewRevealWidth = 240
            btnMenu.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: UIControlEvents.touchUpInside)
            self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
    
    // MARK: Set Screen LayOut
    
    func setScreenLayOut() {
        
        btnCountryList.layer.cornerRadius = btnCountryList.frame.size.width / 2
        btnCountryList.clipsToBounds = true
        
        btnIndustryList.layer.cornerRadius = btnIndustryList.frame.size.width / 2
        btnIndustryList.clipsToBounds = true
        
        btnCategoryList.layer.cornerRadius = btnCategoryList.frame.size.width / 2
        btnCategoryList.clipsToBounds = true
    }
    
    // MARK:- UITableView Data Source And Delegate Method
    
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int
    {
        if tableView == self.searchDisplayController!.searchResultsTableView {
            return arrFilterList.count 
        } else {
            return itemsInTable.count 
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tblCompanyList.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! HomeScreenListTableViewCell
        
        
        
        cell.btnLike.tag = indexPath.row
        cell.btnUnLike.tag = indexPath.row
        cell.btnShare.tag = indexPath.row
        
        if tableView == self.searchDisplayController!.searchResultsTableView {
            dictCompanyDetail=arrFilterList .object(at: indexPath.row) as! NSMutableDictionary
            
            if arrLikeCompanyList .contains(arrFilterList .object(at: indexPath.row)) {
                
                cell.btnUnLike .addTarget(self, action: #selector(btnUnLikeCompany(sender:)), for: UIControlEvents.touchUpInside)
                cell.btnUnLike.isHidden=false
                cell.btnLike.isHidden=true
            }else{
                cell.btnLike .addTarget(self, action: #selector(btnLikeCompany(sender:)), for: UIControlEvents.touchUpInside)
                cell.btnUnLike.isHidden=true
                cell.btnLike.isHidden=false
            }
        } else {
            dictCompanyDetail=itemsInTable .object(at: indexPath.row) as! NSMutableDictionary
            
            print(arrLikeCompanyList);
            
            if arrLikeCompanyList .contains(itemsInTable .object(at: indexPath.row)) {
                
                cell.btnUnLike .addTarget(self, action: #selector(btnUnLikeCompany(sender:)), for: UIControlEvents.touchUpInside)
                cell.btnUnLike.isHidden=false
                cell.btnLike.isHidden=true
            }else{
                cell.btnLike .addTarget(self, action: #selector(btnLikeCompany(sender:)), for: UIControlEvents.touchUpInside)
                cell.btnUnLike.isHidden=true
                cell.btnLike.isHidden=false
            }
            
        
        }
        
        cell.btnShare .addTarget(self, action: #selector(btnCompnayShare(sender:)), for: UIControlEvents.touchUpInside)
        
        cell.lblCompanyName.text = dictCompanyDetail .object(forKey: "name") as? String
        cell.lblCompanyYear.text = dictCompanyDetail .object(forKey: "year") as? String
        
        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if (self.searchDisplayController?.isActive)!{
            
            dictCompanyDetail = arrFilterList .object(at: indexPath.row) as! NSMutableDictionary
            self.performSegue(withIdentifier: "Detail", sender: self)
        }else{
            dictCompanyDetail = itemsInTable .object(at: indexPath.row) as! NSMutableDictionary
            self.performSegue(withIdentifier: "Detail", sender: self)

        }
    }
    
 
    // MARK: UITableView Like Company
    
    func btnLikeCompany(sender: UIButton!) {

        print(itemsInTable .object(at: sender.tag))

        
        if (self.searchDisplayController?.isActive)!{
            arrLikeCompanyList .add(arrFilterList .object(at: sender.tag))
            tblCompanyList .reloadData()
        }else{
            arrLikeCompanyList .add(itemsInTable .object(at: sender.tag))
            tblCompanyList .reloadData()
        }
        
        
        userDefaults.set(arrLikeCompanyList, forKey: "Favorite")
        userDefaults.synchronize()
        
        
        print("\(UserDefaults.standard.value(forKey: "Favorite")!)")
        
    }
    
    
    // MARK: UITableView UnLike Company
    
    
    func btnUnLikeCompany(sender: UIButton!) {
        
        print(itemsInTable .object(at: sender.tag))
        
        if (self.searchDisplayController?.isActive)!{
            arrLikeCompanyList .remove(arrFilterList .object(at: sender.tag))
            tblCompanyList .reloadData()
        }else{
            arrLikeCompanyList .remove(itemsInTable .object(at: sender.tag));
            tblCompanyList .reloadData()
        }

        
        userDefaults.set(arrLikeCompanyList, forKey: "Favorite")
        userDefaults.synchronize()
    }
    
    
    // MARK: UITbaleView Share Comapany
    
    func btnCompnayShare(sender: UIButton!) {
        
        
        if (self.searchDisplayController?.isActive)!{
            
            dictCompanyDetail = arrFilterList .object(at: sender.tag) as! NSMutableDictionary
        }else{
            dictCompanyDetail = itemsInTable .object(at: sender.tag) as! NSMutableDictionary
            
        }
        
        
        
        let myWebsite = NSURL(string:dictCompanyDetail .object(forKey: "Url") as! String)
        
        guard let url = myWebsite else {
            print("nothing found")
            return
        }
        
        print(url)
        
        // set up activity view controller
        let textToShare = [ url ]
        let activityViewController = UIActivityViewController(activityItems: textToShare, applicationActivities: nil)
        if #available(iOS 8.0, *) {
            activityViewController.popoverPresentationController?.sourceView = self.view
        } else {
            // Fallback on earlier versions
        } // so that iPads won't crash
        
        // exclude some activity types from the list (optional)
        activityViewController.excludedActivityTypes = [ UIActivityType.airDrop, UIActivityType.postToFacebook ]
        
        // present the view controller
        self.present(activityViewController, animated: true, completion: nil)
    }
    
    
    // MARK: UITableView Search Method
    
    func filterContentForSearchText(searchText: String) {
        let resultPredicate = NSPredicate(format: "name contains[c]%@", searchText)
        arrFilterList = (itemsInTable as NSArray).filtered(using: resultPredicate) as NSArray
        print(arrFilterList)
    }
    
    func searchDisplayController(_ controller: UISearchDisplayController, shouldReloadTableForSearchString searchString: String) -> Bool {
        

        filterContentForSearchText(searchText: searchString)
        return true
    }
    
    

  
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        
        if segue.identifier == "Detail" {
            
            let vcCompanyCaseDetail = segue.destination as? CompanyDetailViewController
            vcCompanyCaseDetail?.dictCompanyDetail = dictCompanyDetail
            
        }
        
    }
    

}
