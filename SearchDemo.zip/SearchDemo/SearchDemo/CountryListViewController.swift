//
//  CountryListViewController.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class CountryListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    // MARK: Outlet

    @IBOutlet var tblCountryList: UITableView!
    
    
    
    let arrCountryList:NSMutableArray = ["Any","Acia","Pacific", "Japan","Europe", "Middle East", "Africa","Latin America", "North America"]
    var arrFilterList = NSArray()

    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    // MARK: Set Status Bar Color
    
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK:- UITableView Data Source And Delegate Method

    
    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int
    {
        if tableView == self.searchDisplayController!.searchResultsTableView {
            return arrFilterList.count
        } else {
            return arrCountryList.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 44.0
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tblCountryList.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! MenuListTableViewCell
        
        
        if tableView == self.searchDisplayController!.searchResultsTableView {
            cell.lblMenuName.text = arrFilterList .object(at: indexPath.row) as? String
        } else {
            cell.lblMenuName.text = arrCountryList .object(at: indexPath.row) as? String
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.navigationController? .popViewController(animated: false)
    }
    
    // MARK: UITableView Search Method
    
    func filterContentForSearchText(searchText: String) {
        let resultPredicate = NSPredicate(format: "SELF contains[cd]%@", searchText)
        arrFilterList = (arrCountryList as NSArray).filtered(using: resultPredicate) as NSArray
        print(arrFilterList)
    }
    
    func searchDisplayController(_ controller: UISearchDisplayController, shouldReloadTableForSearchString searchString: String) -> Bool {
        
        
        filterContentForSearchText(searchText: searchString)
        return true
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    
    // MARK: Action
    
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController? .popViewController(animated: false)
    }
}
