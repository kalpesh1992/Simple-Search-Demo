//
//  CompanyDetailViewController.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class CompanyDetailViewController: UIViewController, UIWebViewDelegate {
    
    
    
    // MARK: Outlet
    @IBOutlet var lblCompanyName: UILabel!
    @IBOutlet var webView: UIWebView!
    
    
    var dictCompanyDetail:NSMutableDictionary = NSMutableDictionary()
    var hud:MBProgressHUD = MBProgressHUD()
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        hud = MBProgressHUD.showAdded(to: self.view, animated: true)

        lblCompanyName.text = dictCompanyDetail .object(forKey: "name") as? String
        
        webView.loadRequest(URLRequest(url: URL(string: dictCompanyDetail .object(forKey: "Url") as! String)!))
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Set Status Bar Color
    
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    
    // MARK: UIWebView Delegate Method
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        hud .hide(animated: true);
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        hud .hide(animated: true);

    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    
    
    // MARK: Action
    @IBAction func btnBack(_ sender: Any) {
        self.navigationController? .popViewController(animated: true)
    }

}
