//
//  CompanyDetailViewController.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class CompanyDetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Set Status Bar Color
    
    override var preferredStatusBarStyle : UIStatusBarStyle {
        return .lightContent
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
