//
//  MenuListViewController.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 09/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit


class MenuListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let arrMenuList:NSMutableArray = ["Home","Favorite","Setting","Sync","Information","Setting"]
    var dictMenuDetail:NSString = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    // MARK:- UITableView Data Source And Delegate Method

    func tableView(_ tableView:UITableView, numberOfRowsInSection section:Int) -> Int
    {
        return arrMenuList .count
    }
    
    internal func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! MenuListTableViewCell
       
        
        cell.lblMenuName.text = arrMenuList .object(at: indexPath.row) as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        
        revealViewController() .revealToggle(animated: true)

        switch indexPath.row {
        case 0:
            self .performSegue(withIdentifier: "Home", sender: self)
            break
        case 1:
            self .performSegue(withIdentifier: "Favorite", sender: self)
            break
        case 2:
            self .performSegue(withIdentifier: "Home", sender: self)
            break
        case 3:
            self .performSegue(withIdentifier: "Home", sender: self)
            break
        case 4:
            self .performSegue(withIdentifier: "Home", sender: self)
            break
        default:
            self .performSegue(withIdentifier: "Home", sender: self)
            break
        }
            
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
