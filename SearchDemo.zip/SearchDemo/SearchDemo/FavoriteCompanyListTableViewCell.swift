//
//  FavoriteCompanyListTableViewCell.swift
//  SearchDemo
//
//  Created by Kalpesh Satasiya on 10/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

import UIKit

class FavoriteCompanyListTableViewCell: UITableViewCell {
    
    
    // MARK: Outlet
    
    @IBOutlet var lblCompanyName: UILabel!
    @IBOutlet var lblCompnayYear: UILabel!
    @IBOutlet var btnUnLike: UIButton!
    @IBOutlet var btnShare: UIButton!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
