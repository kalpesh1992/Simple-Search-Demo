//
//  ViewController.h
//  DemoOpacityImage
//
//  Created by Kalpesh Satasiya on 15/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "WBMaskedImageView.h"


@interface ViewController : UIViewController

- (IBAction)btnClick:(id)sender;
@property (strong, nonatomic) IBOutlet UIImageView *image1;
@property (strong, nonatomic) IBOutlet UIImageView *image2;
- (IBAction)ClickSlider:(id)sender;
@property (strong, nonatomic) IBOutlet UISlider *ClickSlider;
- (IBAction)btnSave:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *viewMerageImage;
@property (strong, nonatomic) IBOutlet WBMaskedImageView *imgMasking;

@end

