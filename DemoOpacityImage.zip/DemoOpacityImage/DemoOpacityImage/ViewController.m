//
//  ViewController.m
//  DemoOpacityImage
//
//  Created by Kalpesh Satasiya on 15/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "ViewController.h"
#import "FinalShowImageViewController.h"

@interface ViewController (){
    UIImageView* imgView; // your UIImageView
    UIImage *setImage1,*setImage2;
    NSData *imageData;
    
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    _ClickSlider.minimumValue = 0.2;
    _ClickSlider.maximumValue = 0.7;
    
    
    
    
    UIGraphicsEndImageContext();
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



#pragma -mark Marge Two ImageView




 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
     
     if ([segue.identifier isEqualToString:@"Show"]) {
         FinalShowImageViewController *vcFinalShowImage=(FinalShowImageViewController *)segue.destinationViewController;
         vcFinalShowImage.image3 = _imgMasking;
         vcFinalShowImage.imageAlpha = imageData;
     }
     
 }


- (IBAction)btnClick:(id)sender {
    [self performSegueWithIdentifier:@"Show" sender:self];
}
- (IBAction)ClickSlider:(id)sender {
    
    UIImage *originalImage = [UIImage imageNamed:@"ic_virat"]; //my background image
    UIImage *maskedImage       = [UIImage imageNamed:@"ic_blue"]; //my masked image
    
    
    
    CGSize newSize = CGSizeMake(originalImage.size.width, maskedImage.size.height);
    UIGraphicsBeginImageContext( newSize );
    
    
    [originalImage drawInRect:CGRectMake(0,0,newSize.width,newSize.height)];
    
    
    [maskedImage drawInRect:CGRectMake(0,0,newSize.width,newSize.height) blendMode:kCGBlendModeNormal alpha:_ClickSlider.value];
    
    UIImage *newMaskedBackGroundImage = UIGraphicsGetImageFromCurrentImageContext();

    _image2.image = newMaskedBackGroundImage;
    
    
    imageData=UIImageJPEGRepresentation(_image2.image, 0.5);
    NSLog(@"%@",imageData);
}




- (UIImage *)translucentImageFromImage:(UIImage *)image withAlpha:(CGFloat)alpha
{
    CGRect rect = CGRectZero;
    rect.size = image.size;
    
    UIGraphicsBeginImageContext(image.size);
    [image drawInRect:rect blendMode:kCGBlendModeScreen alpha:alpha];
    UIImage * translucentImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    
    return translucentImage;
}
- (IBAction)btnSave:(id)sender {
    
}
@end
