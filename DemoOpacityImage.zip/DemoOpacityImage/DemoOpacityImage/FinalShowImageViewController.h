//
//  FinalShowImageViewController.h
//  DemoOpacityImage
//
//  Created by Kalpesh Satasiya on 15/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FinalShowImageViewController : UIViewController


@property (strong, nonatomic) UIImageView *image1;
@property (strong, nonatomic) UIImageView *image2;
@property (nonatomic,strong) NSData *imageAlpha;

@property (strong, nonatomic) IBOutlet UIImageView *image3;
- (IBAction)btnBack:(id)sender;
@end
