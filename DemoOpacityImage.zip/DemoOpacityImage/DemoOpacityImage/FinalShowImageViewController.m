//
//  FinalShowImageViewController.m
//  DemoOpacityImage
//
//  Created by Kalpesh Satasiya on 15/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "FinalShowImageViewController.h"


@interface FinalShowImageViewController ()

@end

@implementation FinalShowImageViewController
@synthesize image1,image2,imageAlpha;

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    NSLog(@"%@",imageAlpha);
    
    _image3.image=[UIImage imageWithData:imageAlpha];

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:false];
}
@end
