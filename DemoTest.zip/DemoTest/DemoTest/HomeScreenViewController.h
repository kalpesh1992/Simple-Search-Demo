//
//  HomeScreenViewController.h
//  DemoTest
//
//  Created by Kalpesh Satasiya on 04/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeScreenViewController : UIViewController


#pragma -mark Outlet

@property (strong, nonatomic) IBOutlet UIButton *btnMenu;
@property (strong, nonatomic) IBOutlet UITableView *tblSearchList;




#pragma -mark Action




@end
