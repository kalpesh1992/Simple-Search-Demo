//
//  CountryListTableViewCell.h
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CountryListTableViewCell : UITableViewCell


#pragma -mark Outlet

@property (strong, nonatomic) IBOutlet UILabel *lblCountryName;

@end
