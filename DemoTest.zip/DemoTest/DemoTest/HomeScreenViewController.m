//
//  HomeScreenViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 04/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "HomeScreenViewController.h"
#import "SWRevealViewController.h"
#import "HomeScreenListTableViewCell.h"
#import "CompanyDetailViewController.h"

@interface HomeScreenViewController (){
    NSMutableArray *arrLikeCompanylist;
    NSArray *arrFilterList;
    NSMutableDictionary *dictCompanyDetail;
    NSString *strToggle;
}

@end

@implementation HomeScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self leftSlider];
    [self memoryAllocation];
}

#pragma -mark Left Slider

-(void)leftSlider{
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [_btnMenu addTarget:revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}

#pragma -mark Memory Allocation

-(void)memoryAllocation{
    dictCompanyDetail=[[NSMutableDictionary alloc]init];
    arrLikeCompanylist=[[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"Favourite"]];
    
    NSDictionary *dict=[[NSDictionary alloc] initWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"HomeScreenList" ofType:@"plist"]];
    self.items=[dict valueForKey:@"Items"];
    self.itemsInTable=[[NSMutableArray alloc] init];
    [self.itemsInTable addObjectsFromArray:self.items];
    
    
    NSLog(@"%@",self.itemsInTable);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return 1;
    } else {
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 96.0f;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [arrFilterList count];
    } else {
        return [self.itemsInTable count];
    }
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *MyIdentifier = @"Cell";
    
    HomeScreenListTableViewCell *cell = (HomeScreenListTableViewCell *)[self.tblSearchList dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if(cell == nil)
    {
        cell = [[HomeScreenListTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                            reuseIdentifier:MyIdentifier];
    }
    
    cell.btnLike.tag = indexPath.row;
    cell.btnUnLike.tag = indexPath.row;

    
    if (tableView == self.searchDisplayController.searchResultsTableView)  {
        strToggle=@"SearchList";

        dictCompanyDetail=[arrFilterList objectAtIndex:indexPath.row];
        
        if([arrLikeCompanylist containsObject:[arrFilterList objectAtIndex:indexPath.row]])
        {
            [cell.btnUnLike addTarget:self action:@selector(btnUnLikeCompany:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnUnLike.hidden=false;
            cell.btnLike.hidden=true;
        }
        else
        {
            [cell.btnLike addTarget:self action:@selector(btnLikeCompany:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnUnLike.hidden=true;
            cell.btnLike.hidden=false;
        }
    } else {
        strToggle=@"NotSearchList";

        dictCompanyDetail=[self.itemsInTable objectAtIndex:indexPath.row];
       
        if([arrLikeCompanylist containsObject:[self.itemsInTable objectAtIndex:indexPath.row]])
        {
            [cell.btnUnLike addTarget:self action:@selector(btnUnLikeCompany:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnUnLike.hidden=false;
            cell.btnLike.hidden=true;
        }
        else
        {
            [cell.btnLike addTarget:self action:@selector(btnLikeCompany:) forControlEvents:UIControlEventTouchUpInside];
            cell.btnUnLike.hidden=true;
            cell.btnLike.hidden=false;
        }
    }
    
    
   
    
    cell.lblSearchList.text=[dictCompanyDetail objectForKey:@"name"];
    cell.lblYear.text=[dictCompanyDetail objectForKey:@"year"];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    if (self.searchDisplayController.active){
        [self performSegueWithIdentifier:@"Detail" sender:[arrFilterList objectAtIndex:indexPath.row]];
        
    }else{
        [self performSegueWithIdentifier:@"Detail" sender:[self.itemsInTable objectAtIndex:indexPath.row]];
        
    }
    
}

#pragma -mark Like And UnLike

-(void)btnLikeCompany:(UIButton *)sender{
    if (self.searchDisplayController.active)  {
        [arrLikeCompanylist addObject:[arrFilterList objectAtIndex:[sender tag]]];
        [self.tblSearchList reloadData];
        
    } else {
        [arrLikeCompanylist addObject:[self.itemsInTable objectAtIndex:[sender tag]] ];
        [self.tblSearchList reloadData];
        
    }
    
    [[NSUserDefaults standardUserDefaults]setObject:arrLikeCompanylist forKey:@"Favourite"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    
}

-(void)btnUnLikeCompany:(UIButton *)sender{
    if (self.searchDisplayController.active)  {
        [arrLikeCompanylist removeObject:[arrFilterList objectAtIndex:[sender tag]]];
        [self.tblSearchList reloadData];
        
    } else {
        [arrLikeCompanylist removeObject:[self.itemsInTable objectAtIndex:[sender tag]]];
        [self.tblSearchList reloadData];
        
    }
    
    [[NSUserDefaults standardUserDefaults]setObject:arrLikeCompanylist forKey:@"Favourite"];
    [[NSUserDefaults standardUserDefaults]synchronize];


}


- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"name contains[c] %@",
                                    searchText];
    arrFilterList= [self.itemsInTable filteredArrayUsingPredicate:resultPredicate];
    NSLog(@"%@",arrFilterList);
    
    
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]] ;
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([[segue identifier] isEqualToString:@"Detail"]){
        NSLog(@"%@",segue.identifier);
        CompanyDetailViewController *vc = [segue destinationViewController];
        [vc performSelector:@selector(filltheDetailWith:) withObject:(NSDictionary *)sender afterDelay:0.02];
    }
}


@end
