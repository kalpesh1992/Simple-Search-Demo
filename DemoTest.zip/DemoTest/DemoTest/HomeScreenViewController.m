//
//  HomeScreenViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 04/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "HomeScreenViewController.h"
#import "SWRevealViewController.h"
#import "HomeScreenListTableViewCell.h"

@interface HomeScreenViewController (){
    NSMutableArray *arrSearchList;
    NSArray *arrFilterList;
}

@end

@implementation HomeScreenViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self leftSlider];
    [self memoryAllocation];
}

#pragma -mark Left Slider

-(void)leftSlider{
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [_btnMenu addTarget:revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}

#pragma -mark Memory Allocation

-(void)memoryAllocation{
    arrSearchList=[[NSMutableArray alloc]initWithObjects:@"Canada",@"China",@"France",@"Germany",@"India",@"Japan",@"Pakistan",@"United Kingdom",@"United States",@"Abkhazia",@"Abkhazia",@"Afghanistan",@"Albania",@"Algeria",@"American Samoa",@"Andorra",@"Angola",@"Anguilla",@"Antigua and Barbuda",@"Argentina",@"Armenia",@"Aruba",@"Ascension",@"Australia",@"Austria",@"Azerbaijan",@"Bahamas",@"Bahrain",@"Bangladesh",@"Barbados",@"Barbuda",@"Belarus",@"Belgium",@"Canada",@"Cape Verde",@"Cayman Islands",@"Central African Republic",@"Chad",@"Chile",@"China",@"Christmas Island",@"Cocos-Keeling Islands",@"Colombia",@"Comoros",@"Congo2",@"Congo, Dem. Rep. of (Zaire)",@"Cook Islands",@"Costa Rica",@"Ivory Coast", @"Croatia",@"Cuba",@"Curacao",@"Cyprus",@"+537",@"Czech Republic",@"Denmark",@"Diego Garcia",@"Djibouti",@"Dominica",@"East Timor",@"Adilabad",@"Agra",@"Ahmedabad",@"Ahmednagar",@"Aizawl",@"Ajitgarh (Mohali)",@"Ajmer",@"Akola",@"Alappuzha",@"Aligarh",@"Alirajpur",@"Allahabad",@"Almora",@"Alwar",@"Ambala",@"Ambedkar Nagar",@"Amravati",@"Amreli district",@"Amritsar",@"Anand",@"Anantapur",@"Anantnag",@"Angul",@"Anjaw",@"Anuppur",@"Araria",@"Ariyalur",@"Arwal",@"Ashok Nagar",@"Auraiya",@"Aurangabad",@"Aurangabad",@"Azamgarh",@"Badgam",@"Bagalkot",@"Bageshwar",@"Bagpat",@"Bahraich",@"Baksa",@"Balaghat",@"Balangir",@"Balasore",@"Ballia",@"Balrampur",@"Banaskantha",@"Banda",@"Bandipora",@"Bangalore Rural",@"Bangalore Urban",@"Banka",@"Bankura",@"Banswara",@"Barabanki",@"Bhopal",@"Baramulla",@"Bareilly",@"Boudh (Bauda)",@"Budaun",@"Bulandshahr",@"Buldhana",@"Bundi",@"Central Delhi",@"Chamarajnagar",@"Chamba",@"Chamoli",@"Champawat",@"Champhai",@"Chandauli",@"Chandel",@"Chandigarh",@"Chandrapur",@"Changlang",@"Chatra",@"Chennai",@"Chhatarpur",@"Chhatrapati Shahuji Maharaj Nagar",@"Chhindwara",@"Chikkaballapur",@"Chikkamagaluru",@"Chirang",@"Chitradurga",@"Chitrakoot",@"Chittoor@",
                   @"Chittorgarh",
                   @"Churachandpur",
                   @"Churu",
                   @"Coimbatore",
                   @"Cooch Behar",
                   @"Cuddalore",
                   @"Cuttack",
                   @"Dadra and Nagar Haveli",
                   @"Dahod",
                   @"Dakshin Dinajpur",
                   @"Dakshina Kannada",
                   @"Daman",
                   @"Damoh",
                   @"Dantewada",
                   @"Darbhanga",
                   @"Darjeeling",
                   @"Darrang",
                   @"Datia",
                   @"Davanagere",
                   @"Debagarh (Deogarh)",
                   @"Dehradun",
                   @"Deoghar",
                   @"Deoria",
                   @"Dewas",
                   @"Dhalai",
                   @"Dhamtari",
                   @"Dhanbad",
                   @"Dhar",
                   @"Dharmapuri",
                   @"Dharwad",
                   @"Dhemaji",
                   @"Dhenkanal",
                   @"Dholpur",
                   @"Dhubri",
                   @"Dhule",
                   @"Dibang Valley",
                   @"Dibrugarh",
                   @"Dima Hasao",
                   @"Dimapur",
                   @"Dindigul",
                   @"Dindori",
                   @"Diu",
                   @"Doda",
                   @"Dumka",
                   @"Dungapur",
                   @"Durg",
                   @"East Champaran",
                   @"East Delhi",
                   @"East Garo Hills",
                   @"East Khasi Hills",
                   @"East Siang",
                   @"East Sikkim",
                   @"East Singhbhum",
                   @"Eluru",
                   @"Ernakulam",
                   @"Erode",
                   @"Etah",
                   @"Etawah",
                   @"Faizabad",
                   @"Faridabad",
                   @"Faridkot",
                   @"Farrukhabad",
                   @"Fatehabad",
                   @"Fatehgarh Sahib",
                   @"Fatehpur",
                   @"Fazilka",
                   @"Firozabad",
                   @"Firozpur",
                   @"Gadag",
                   @"Gadchiroli",
                   @"Gajapati",
                   @"Ganderbal",
                   @"Gandhinagar",
                   @"Ganganagar",
                   @"Ganjam",
                   @"Garhwa",
                   @"Gautam Buddh Nagar",
                   @"Gaya",
                   @"Ghaziabad",
                   @"Ghazipur",
                   @"Giridih",
                   @"Goalpara",
                   @"Godda",
                   @"Golaghat",
                   @"Gonda",
                   @"Gondia",
                   @"Gopalganj",
                   @"Gorakhpur",
                   @"Gulbarga",
                   @"Gumla",
                   @"Guna",
                   @"Guntur",
                   @"Gurdaspur",
                   @"Gurgaon",
                   @"Gwalior",
                   @"Hailakandi",
                   @"Hamirpur",
                   @"Hamirpur",@"Easter Island",@"Ecuador",@"Egypt",@"El Salvador",@"Equatorial Guinea", @"+240",@"Eritrea",@"Estonia",@"Ethiopia",@"Falkland Islands",@"Faroe Islands",@"Fiji",@"Finland",@"Franc",@"French", nil];

   
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return 1;
    } else {
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 44.0f;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [arrFilterList count];
    } else {
        return [arrSearchList count];
    }
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *MyIdentifier = @"Cell";
    
    HomeScreenListTableViewCell *cell = (HomeScreenListTableViewCell *)[self.tblSearchList dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if(cell == nil)
    {
        cell = [[HomeScreenListTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                            reuseIdentifier:MyIdentifier];
    }
    
    
    if (tableView == self.searchDisplayController.searchResultsTableView)  {
        cell.lblSearchList.text=[arrFilterList objectAtIndex:indexPath.row];
        
    } else {
        cell.lblSearchList.text=[arrSearchList objectAtIndex:indexPath.row];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
   
    
    
}



- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF contains[cd] %@",
                                    searchText];
    arrFilterList= [arrSearchList filteredArrayUsingPredicate:resultPredicate];
    NSLog(@"%@",arrFilterList);
    
    
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]] ;
    return YES;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
