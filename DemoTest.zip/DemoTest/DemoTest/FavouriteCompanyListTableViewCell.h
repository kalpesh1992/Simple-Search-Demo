//
//  FavouriteCompanyListTableViewCell.h
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavouriteCompanyListTableViewCell : UITableViewCell


#pragma -mark Outlet

@property (strong, nonatomic) IBOutlet UILabel *lblCompanyName;
@property (strong, nonatomic) IBOutlet UILabel *lblYearName;

@property (strong, nonatomic) IBOutlet UIButton *btnUnLike;
@property (strong, nonatomic) IBOutlet UIButton *btnShare;

@end
