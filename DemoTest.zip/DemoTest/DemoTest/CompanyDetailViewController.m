//
//  CompanyDetailViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "CompanyDetailViewController.h"

@interface CompanyDetailViewController (){
    NSMutableDictionary *dictCompanyDetail;
}

@end

@implementation CompanyDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)filltheDetailWith:(NSDictionary *)dMain{
    
    NSLog(@"%@",dMain);
       
    
    _lblCompnayName.text=[dMain valueForKey:@"name"];
    
    if ([[dMain valueForKey:@"name"] isEqualToString:@"Reliance"]) {
        
        NSString *sPathPDF = @"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Ford"]){
        NSString *sPathPDF = @"http://www.pdf995.com/samples/pdf.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Facebook"]){
        NSString *sPathPDF = @"http://foersom.com/net/HowTo/data/OoPdfFormExample.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Google"]){
        NSString *sPathPDF = @"https://online.wsj.com/public/resources/documents/Reprint_Samples.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Twitter"]){
        NSString *sPathPDF = @"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Tata"]){
        NSString *sPathPDF = @"http://unec.edu.az/application/uploads/2014/12/pdf-sample.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Apple"]){
        NSString *sPathPDF = @"http://qmplus.qmul.ac.uk/pluginfile.php/612547/mod_resource/content/1/pdf.pdf";
        
        NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
        
        [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}
@end
