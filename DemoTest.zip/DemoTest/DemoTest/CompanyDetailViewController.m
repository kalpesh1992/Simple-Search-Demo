//
//  CompanyDetailViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "CompanyDetailViewController.h"

@interface CompanyDetailViewController (){
    NSMutableDictionary *dictCompanyDetail;
}

@end

@implementation CompanyDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


#pragma -mark Set Status bar Color

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (void)filltheDetailWith:(NSDictionary *)dMain{
    
    NSLog(@"%@",dMain);
       
    
    _lblCompnayName.text=[dMain valueForKey:@"name"];
   
    NSString *sPathPDF = [dMain valueForKey:@"Url"];
    NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
    [_webView loadRequest:[NSURLRequest requestWithURL:urls]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}
@end
