//
//  CompanyDetailViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "CompanyDetailViewController.h"

@interface CompanyDetailViewController (){
    NSMutableDictionary *dictCompanyDetail;
}

@end

@implementation CompanyDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)filltheDetailWith:(NSDictionary *)dMain{
    
    NSLog(@"%@",dMain);
       
    
    _lblCompnayName.text=[dMain valueForKey:@"name"];
    
    if ([[dMain valueForKey:@"name"] isEqualToString:@"Reliance"]) {
        
        NSString *sPathPDF = [[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0] stringByAppendingPathComponent:[NSString stringWithFormat:@"12270.pdf"]]; //path example for a local stored pdf
        NSURL *urlPDF = [NSURL fileURLWithPath:sPathPDF];
        UIDocumentInteractionController *dicPDF = [UIDocumentInteractionController interactionControllerWithURL: urlPDF];
        [dicPDF setDelegate:self];
        [dicPDF presentPreviewAnimated: YES];
        
//        NSURL *urls=[[NSURL alloc]initWithString:str];
//        
//        [_webView loadRequest:[NSURLRequest requestWithURL:urlPDF]];
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Ford"]){
    
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Facebook"]){
    
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Google"]){
    
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Twitter"]){
        
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Tata"]){
        
    }else if ([[dMain valueForKey:@"name"] isEqualToString:@"Apple"]){
        
    }
    
    
    
}
- (UIViewController *)documentInteractionControllerViewControllerForPreview:(UIDocumentInteractionController *)controller
{
    return self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:true];
}
@end
