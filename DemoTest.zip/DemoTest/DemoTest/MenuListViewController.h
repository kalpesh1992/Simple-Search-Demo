//
//  MenuListViewController.h
//  DemoTest
//
//  Created by Kalpesh Satasiya on 04/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MenuListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>


#pragma -mark Outlet

@property (strong, nonatomic) IBOutlet UITableView *tblMenuList;


#pragma -mark Action



@end
