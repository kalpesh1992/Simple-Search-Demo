//
//  IndustryListViewController.h
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndustryListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>


@property(nonatomic,strong) NSArray *items;
@property (nonatomic, retain) NSMutableArray *itemsInTable;

#pragma -mark Outlet

@property (strong, nonatomic) IBOutlet UITableView *tblindustryList;

#pragma -mark Action

- (IBAction)btnBack:(id)sender;


@end
