//
//  CountryListViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "CountryListViewController.h"
#import "CountryListTableViewCell.h"

@interface CountryListViewController (){
    NSArray *arrFilterList;
}

@end

@implementation CountryListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
//     = ["Any","Acia, Pacific, Japan","Europe, Middle East, Africa","Latin America", "North America"]
    
    self.itemsInTable=[[NSMutableArray alloc]initWithObjects:@"Any",@"Acia",@"Pacific", @"Japan",@"Europe", @"Middle East", @"Africa",@"Latin America", @"North America", nil];
    [self setScreenLayOut];
}


#pragma -mark Set Status bar Color

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}


#pragma -mark UITableView PopUp Animation

-(void)setScreenLayOut{
    self.viewBlur.blurRadius=10;
    _viewBlur.alpha=1.0;
    
    _tblCountryList.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    
    [UIView animateWithDuration:0.3/1.5 animations:^{
        _tblCountryList.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.1, 1.1);
    }
                     completion:^(BOOL finished) {
                         [UIView animateWithDuration:0.3/2 animations:^{
                             _tblCountryList.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
                         } completion:^(BOOL finished) {
                             [UIView animateWithDuration:0.3/2 animations:^{
                                 _tblCountryList.transform = CGAffineTransformIdentity;
                             }];
                         }];
                     }];

}

#pragma -mark UITableView Delegate And Data Source Method


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return 1;
    } else {
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 40.0f;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [arrFilterList count];
    } else {
        return [self.itemsInTable count];
    }
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *MyIdentifier = @"Cell";
    
    CountryListTableViewCell *cell = (CountryListTableViewCell *)[self.tblCountryList dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if(cell == nil)
    {
        cell = [[CountryListTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                                  reuseIdentifier:MyIdentifier];
    }

    
    
    if (tableView == self.searchDisplayController.searchResultsTableView)  {
        cell.lblCountryName.text=[arrFilterList objectAtIndex:indexPath.row];
    } else {
        cell.lblCountryName.text=[self.itemsInTable objectAtIndex:indexPath.row];

    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
  
    
}

#pragma -mark Search TbaleView Cell Country Name


- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF contains[cd] %@",
                                    searchText];
    arrFilterList= [self.itemsInTable filteredArrayUsingPredicate:resultPredicate];
    NSLog(@"%@",arrFilterList);
    
    
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]] ;
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:false];
}
@end
