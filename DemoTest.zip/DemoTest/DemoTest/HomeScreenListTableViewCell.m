//
//  HomeScreenListTableViewCell.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 04/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "HomeScreenListTableViewCell.h"

@implementation HomeScreenListTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
