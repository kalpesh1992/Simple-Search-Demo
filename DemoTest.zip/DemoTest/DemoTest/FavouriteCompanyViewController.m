//
//  FavouriteCompanyViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 05/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "FavouriteCompanyViewController.h"
#import "SWRevealViewController.h"
#import "FavouriteCompanyListTableViewCell.h"
#import "CompanyDetailViewController.h"

@interface FavouriteCompanyViewController (){
    NSMutableArray *arrFavouriteCompanyList;
    NSMutableDictionary *dictFavouriteCompanyDetail;
}

@end

@implementation FavouriteCompanyViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self leftSlider];
    [self memoryAllocation];
}

#pragma -mark Left Slider

-(void)leftSlider{
    
    SWRevealViewController *revealViewController = self.revealViewController;
    if ( revealViewController )
    {
        [_btnMenu addTarget:revealViewController action:@selector(revealToggle:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}

#pragma -mark Set Status bar Color

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

#pragma -mark Memory Allocation

-(void)memoryAllocation{
    arrFavouriteCompanyList=[[NSMutableArray alloc]initWithArray:[[NSUserDefaults standardUserDefaults] objectForKey:@"Favourite"]];
    dictFavouriteCompanyDetail=[[NSMutableDictionary alloc]init];
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrFavouriteCompanyList count];
}



-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier=@"Cell";
    
    FavouriteCompanyListTableViewCell *cell = (FavouriteCompanyListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Cell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    
    dictFavouriteCompanyDetail=[arrFavouriteCompanyList objectAtIndex:indexPath.row];
    cell.btnUnLike.tag = indexPath.row;

    
    cell.lblCompanyName.text=[dictFavouriteCompanyDetail objectForKey:@"name"];
    cell.lblYearName.text=[dictFavouriteCompanyDetail objectForKey:@"year"];
    
    [cell.btnUnLike addTarget:self action:@selector(btnUnLikeCompany:) forControlEvents:UIControlEventTouchUpInside];
    [cell.btnShare addTarget:self action:@selector(btnShareCompany:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [self performSegueWithIdentifier:@"Detail" sender:[arrFavouriteCompanyList objectAtIndex:indexPath.row]];

}


#pragma -mark UnLike and share Company UIButton Action

-(void)btnUnLikeCompany:(UIButton *)sender{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero
                                           toView:self.tblFavouriteCompnayList];
    NSIndexPath *tappedIP = [self.tblFavouriteCompnayList indexPathForRowAtPoint:buttonPosition];
    
    
    dictFavouriteCompanyDetail=[arrFavouriteCompanyList objectAtIndex:tappedIP.row];
    
    [arrFavouriteCompanyList removeObject:dictFavouriteCompanyDetail];
    [_tblFavouriteCompnayList reloadData];
    
    [[NSUserDefaults standardUserDefaults]setObject:arrFavouriteCompanyList forKey:@"Favourite"];
    [[NSUserDefaults standardUserDefaults]synchronize];
}

-(void)btnShareCompany:(UIButton *)sender{
    CGPoint buttonPosition = [sender convertPoint:CGPointZero
                                           toView:self.tblFavouriteCompnayList];
    NSIndexPath *tappedIP = [self.tblFavouriteCompnayList indexPathForRowAtPoint:buttonPosition];
       
    dictFavouriteCompanyDetail=[arrFavouriteCompanyList objectAtIndex:tappedIP.row];
   
    
    NSString *sPathPDF = [dictFavouriteCompanyDetail valueForKey:@"Url"];
    NSURL *urls=[[NSURL alloc]initWithString:sPathPDF];
    
    NSArray *activityItems = @[urls];
    UIActivityViewController *activityViewControntroller = [[UIActivityViewController alloc] initWithActivityItems:activityItems applicationActivities:nil];
    activityViewControntroller.excludedActivityTypes = @[];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
        activityViewControntroller.popoverPresentationController.sourceView = self.view;
        activityViewControntroller.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/4, 0, 0);
    }
    [self presentViewController:activityViewControntroller animated:true completion:nil];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    
    if ([[segue identifier] isEqualToString:@"Detail"]){
        NSLog(@"%@",segue.identifier);
        CompanyDetailViewController *vc = [segue destinationViewController];
        [vc performSelector:@selector(filltheDetailWith:) withObject:(NSDictionary *)sender afterDelay:0.02];
    }

        
}


@end
