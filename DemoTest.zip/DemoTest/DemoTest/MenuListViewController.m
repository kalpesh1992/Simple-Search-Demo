//
//  MenuListViewController.m
//  DemoTest
//
//  Created by Kalpesh Satasiya on 04/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "MenuListViewController.h"
#import "MenuListTableViewCell.h"
#import "SWRevealViewController.h"

@interface MenuListViewController (){
    NSMutableArray *arrMenuList;
}

@end

@implementation MenuListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self memoryAllocation];
}

#pragma -mark Memory Allocation

-(void)memoryAllocation{
    arrMenuList=[[NSMutableArray alloc]initWithObjects:@"Home",@"Setting",@"Sync",@"information",@"Feedback", nil];
}

#pragma -mark TableView Data Source And Delegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrMenuList count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    return 45;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier=@"Cell";
    
    MenuListTableViewCell *cell = (MenuListTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if(cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"Cell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    cell.lblMenuName.text=[arrMenuList objectAtIndex:indexPath.row];
    
    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    [self.revealViewController revealToggleAnimated:YES];
    
    switch (indexPath.row) {
        case 0:
            [self performSegueWithIdentifier:@"Home" sender:self];
            break;
        case 1:
            [self performSegueWithIdentifier:@"Home" sender:self];
            break;
        case 2:
            [self performSegueWithIdentifier:@"Home" sender:self];
            break;
        case 3:
            [self performSegueWithIdentifier:@"Home" sender:self];
            break;
        case 4:
            [self performSegueWithIdentifier:@"Home" sender:self];
            break;
        default:
            [self performSegueWithIdentifier:@"Home" sender:self];
            break;
    }

    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
