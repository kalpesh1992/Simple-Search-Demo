//
//  CategoryListViewController.h
//  DemoTest
//
//  Created by Steve Rogers on 07/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FXBlurView.h"

@interface CategoryListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>



@property(nonatomic,strong) NSArray *items;
@property (nonatomic, retain) NSMutableArray *itemsInTable;


#pragma -mark Outlet


@property (weak, nonatomic) IBOutlet UITableView *tblCategoryList;
@property (strong, nonatomic) IBOutlet FXBlurView *viewBlur;

#pragma -mark Action

- (IBAction)btnBack:(id)sender;

@end
