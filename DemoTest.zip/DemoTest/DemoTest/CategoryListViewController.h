//
//  CategoryListViewController.h
//  DemoTest
//
//  Created by Steve Rogers on 07/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoryListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>



@property(nonatomic,strong) NSArray *items;
@property (nonatomic, retain) NSMutableArray *itemsInTable;


#pragma -mark Outlet


@property (weak, nonatomic) IBOutlet UITableView *tblCategoryList;

#pragma -mark Action

- (IBAction)btnBack:(id)sender;

@end
