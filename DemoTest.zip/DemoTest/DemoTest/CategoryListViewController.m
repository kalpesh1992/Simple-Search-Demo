//
//  CategoryListViewController.m
//  DemoTest
//
//  Created by Steve Rogers on 07/05/17.
//  Copyright © 2017 Kalpesh Satasiya. All rights reserved.
//

#import "CategoryListViewController.h"
#import "IndustryListTableViewCell.h"

@interface CategoryListViewController (){
    NSArray *arrFilterList;

}

@end

@implementation CategoryListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.itemsInTable=[[NSMutableArray alloc]initWithObjects:@"Sell, Buy & Restructure",@"Harmonization & Unification", @"Consolidation", @"Information Management & Governance", @"SAP Landscape Transformation", nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma -mark Set Status bar Color

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return 1;
    } else {
        return 1;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 40.0f;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [arrFilterList count];
    } else {
        return [self.itemsInTable count];
    }
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *MyIdentifier = @"Cell";
    
    IndustryListTableViewCell *cell = (IndustryListTableViewCell *)[self.tblCategoryList dequeueReusableCellWithIdentifier:MyIdentifier];
    
    if(cell == nil)
    {
        cell = [[IndustryListTableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle
                                               reuseIdentifier:MyIdentifier];
    }
    
    
    
    if (tableView == self.searchDisplayController.searchResultsTableView)  {
        cell.lblIndustryName.text=[arrFilterList objectAtIndex:indexPath.row];
    } else {
        cell.lblIndustryName.text=[self.itemsInTable objectAtIndex:indexPath.row];
        
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    
}

#pragma -mark Search TbaleView Cell Category Name


- (void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope
{
    NSPredicate *resultPredicate = [NSPredicate
                                    predicateWithFormat:@"SELF contains[cd] %@",
                                    searchText];
    arrFilterList= [self.itemsInTable filteredArrayUsingPredicate:resultPredicate];
    NSLog(@"%@",arrFilterList);
    
    
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString
{
    [self filterContentForSearchText:searchString scope:[[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]] ;
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)btnBack:(id)sender {
    [self.navigationController popViewControllerAnimated:false];
}
@end
